# mapping_default
<arg name="base_frame" default="base_footprint"/>
